# SEO & GEO Content Writer Portfolio

A responsive, static HTML/CSS portfolio drafted from the supplied PDF.

## Preview
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `yourname.github.io`).
2. Upload `index.html`, `style.css`, and the `images/` folder to the repository.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site.

## Before publishing
- Replace `hello@example.com` in `index.html` with your real contact email.
- Review the selected work images and update their captions if needed.
- Check all text, dates, and performance figures against your source and update as appropriate.

This site uses Google Fonts via an external stylesheet; it falls back to system fonts if unavailable.
